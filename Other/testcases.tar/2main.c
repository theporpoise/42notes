/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgould <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/10/31 08:34:58 by mgould            #+#    #+#             */
/*   Updated: 2016/10/31 16:22:18 by mgould           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include "../ex02/ft_atoi.c"

int main(void)
{

	printf("%d\n", atoi(" \t\n\v\f\r12 345"));
	printf("%d\n", atoi("    -12345"));
	printf("%d\n", atoi("0"));
	printf("%d\n", atoi("+47564"));
	printf("%d\n", atoi("ABCDE"));
	printf("%d\n", atoi("++1"));
	printf("%d\n", atoi("-23ABCD"));

	printf("my values are \n");

	printf("%d\n", ft_atoi(" \t\n\v\f\r12 345"));
	printf("%d\n", ft_atoi("    -12345"));
	printf("%d\n", ft_atoi("0"));
	printf("%d\n", ft_atoi("+47564"));
	printf("%d\n", ft_atoi("ABCDE"));
	printf("%d\n", ft_atoi("++1"));
	printf("%d\n", ft_atoi("-23ABCD"));

}	
