/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   8main.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgould <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/01 09:22:57 by mgould            #+#    #+#             */
/*   Updated: 2016/11/01 09:26:48 by mgould           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>
#include "../ex08/ft_strupcase.c"

int main(void)
{
	char one[] = 	"abcdefgaaazzz A A Z Z";
	char two[] = 	"1234abcd12345";

	printf("one is:\n%s\n", ft_strupcase(one));
	printf("two is:\n%s\n", ft_strupcase(two));

}
