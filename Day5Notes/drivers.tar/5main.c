/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgould <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/10/31 08:34:58 by mgould            #+#    #+#             */
/*   Updated: 2016/10/31 22:51:08 by mgould           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>
#include "../ex05/ft_strstr.c"

int main(void)
{
	char haystack[] = "abcdefghijklmnop";
	char needle[] = "sdef";

	printf("%s\n%s\n\n", haystack, needle);

	printf("strstr:\n%s\n", strstr(haystack, needle));

	printf("\nmy values are\n\n");

	if (ft_strstr(haystack, needle) == NULL)
	{
		printf("The answer is null\n");
	}
	printf("strstr:\n%s\n", ft_strstr(haystack, needle));


}	
