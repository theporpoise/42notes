/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgould <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/10/31 08:34:58 by mgould            #+#    #+#             */
/*   Updated: 2016/10/31 21:11:41 by mgould           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "../ex03/ft_strcpy.c"
#include <string.h>

int main(void)
{
	char string1[] = "zzzzzzzzzz";
	char string2[] = "helloworld";

	printf("%s\n%s\n\n", string1, string2);

	strcpy(string1, string2);
	printf("string1:\n%s\n", string1);

	printf("\nmy values are\n\n");
	
	ft_strcpy(string1, string2);
	printf("string1:\n%s\n", string1);


}	
