/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   16main.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgould <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/01 20:59:29 by mgould            #+#    #+#             */
/*   Updated: 2016/11/01 21:21:45 by mgould           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>
#include "../ex16/ft_strcat.c"

int main(void)
{
	char one[] = 	"lsfk3#2!kdlsm,";
	char two[] = 	"12abc12ABC$#abc a a z z ";
	char thre[] = "";

/*	//char test1[] = "In the middle 42of your mathematics exam,\n\
the batteries go dead on your calculator.\n\
You put it away in disgust saying, “This machine is out to get me.”\n\
You’ve probably heard someone say “Love is blind.”\n\
The cliché suggests anyone who is in love is unable to s: his\n\
or her lover’s faults. In each of the two examples people have given\n\
human qualities to non-human things.\n\
From the evidence of watching the dog, we presume that the dog is dreaming.\n\
Similarly, the episode with the calculator presumes that the machine will \n\
react like human beings; the calculator wants revenge. \n\
In literature, authors often give human qualities to non-human things. \n\
This technique is called personification.";
*/
	printf("one is:\n%s\n", ft_strcat(one, two));
	printf("two is:\n%s\n", ft_strcat(two, thre));
	//printf("paragraph is:\n%s\n", ft_strcat(test1, one));
	printf("null is:\n%s\n", ft_strcat(thre, two));
	printf("\nthis is two:\n");
	printf("%s", two); 


}
