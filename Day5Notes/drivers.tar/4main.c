/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgould <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/10/31 08:34:58 by mgould            #+#    #+#             */
/*   Updated: 2016/10/31 19:15:30 by mgould           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "../ex04/ft_strncpy.c"
#include <string.h>

int main(void)
{
	char string1[] = "aaaaaaaaaa";
	char string2[] = "yyy";

	printf("%s\n%s\n\n", string1, string2);

	strncpy(string1, string2, 5);
	printf("string1:\n%s\n", string1);
	strncpy(string1, string2, 4);
	printf("string1:\n%s\n", string1);
	strncpy(string1, string2, 3);
	printf("string1:\n%s\n", string1);
	strncpy(string1, string2, 2);
	printf("string1:\n%s\n", string1);
	strncpy(string1, string2, 1);
	printf("string1:\n%s\n", string1);
	strncpy(string1, string2, 0);
	printf("string1:\n%s\n", string1);

	printf("\nmy values are\n\n");
	
	ft_strncpy(string1, string2, 5);
	printf("string1:\n%s\n", string1);
	ft_strncpy(string1, string2, 4);
	printf("string1:\n%s\n", string1);
	ft_strncpy(string1, string2, 3);
	printf("string1:\n%s\n", string1);
	ft_strncpy(string1, string2, 2);
	printf("string1:\n%s\n", string1);
	ft_strncpy(string1, string2, 1);
	printf("string1:\n%s\n", string1);
	ft_strncpy(string1, string2, 0);
	printf("string1:\n%s\n", string1);


}	
