/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgould <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/10/31 08:34:58 by mgould            #+#    #+#             */
/*   Updated: 2016/11/01 17:19:49 by mgould           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include "../ex02/ft_atoi.c"

int main(void)
{

	printf("%d\n", atoi(" \t\n\v\f\r12 345"));
	printf("%d\n", atoi("    -12345"));
	printf("%d\n", atoi("0"));
	printf("%d\n", atoi("+47564"));
	printf("%d\n", atoi("ABCDE"));
	printf("%d\n", atoi("++1"));
	printf("%d\n", atoi("-23ABCD"));
	printf("%d\n", atoi("1234567890678901234567890"));
	printf("%d\n", atoi("-3234567890678901234567890"));
	printf("%d\n", atoi("-323456789067890123"));
	printf("%d\n", atoi("  \n  -  \n5"));


	printf("my values are \n");

	printf("%d\n", ft_atoi(" \t\n\v\f\r12 345"));
	printf("%d\n", ft_atoi("    -12345"));
	printf("%d\n", ft_atoi("0"));
	printf("%d\n", ft_atoi("+47564"));
	printf("%d\n", ft_atoi("ABCDE"));
	printf("%d\n", ft_atoi("++1"));
	printf("%d\n", ft_atoi("-23ABCD"));
	printf("%d\n", ft_atoi("1234567890678901234567890"));
	printf("%d\n", ft_atoi("-3234567890678901234567890"));
	printf("%d\n", ft_atoi("-323456789067890123"));
	printf("%d\n", ft_atoi("  \n  -  \n5"));


}	
