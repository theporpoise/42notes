/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   7main.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgould <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/11/01 08:34:40 by mgould            #+#    #+#             */
/*   Updated: 2016/11/01 08:55:58 by mgould           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>
#include "../ex07/ft_strncmp.c"

int main(void)
{
	char haystack110[] = 	"";
	char needle10[] = 	"";

	printf("both null\n");
	printf("%s\n%s\n\n", haystack110, needle10);

	printf("strncmp:\n%d\n", strncmp(haystack110, needle10, 2));
	printf("ft_strncmp:\n%d\n", ft_strncmp(haystack110, needle10, 2));

	char haystack11[] = 	"abcdef";
	char needle1[] = 	"abcaaa";

	printf("\nequal before cutoff\n");
	printf("%s\n%s\n\n", haystack11, needle1);

	printf("strncmp:\n%d\n", strncmp(haystack11, needle1, 3));
	printf("ft_strncmp:\n%d\n", ft_strncmp(haystack11, needle1, 3));

	char haystack112[] = 	"ab";
	char needle12[] = 	"abcaaa";

	printf("\nless than equal before cutoff\n");
	printf("%s\n%s\n\n", haystack112, needle12);

	printf("strncmp:\n%d\n", strncmp(haystack112, needle12, 3));
	printf("ft_strncmp:\n%d\n", ft_strncmp(haystack112, needle12, 3));

	char haystack3[] = 	"ac";
	char needle3[] = 	"abcaaa";

	printf("\ngreater than equal before cutoff\n");
	printf("%s\n%s\n\n", haystack3, needle3);

	printf("strncmp:\n%d\n", strncmp(haystack3, needle3, 3));
	printf("ft_strncmp:\n%d\n", ft_strncmp(haystack3, needle3, 3));

	char haystack31[] = 	"abcaaa";
	char needle31[] = 	"abcaaa";

	printf("\ncutoff > string length\n");
	printf("%s\n%s\n\n", haystack31, needle31);

	printf("strncmp:\n%d\n", strncmp(haystack31, needle31, 10));
	printf("ft_strncmp:\n%d\n", ft_strncmp(haystack31, needle31, 10));
}
